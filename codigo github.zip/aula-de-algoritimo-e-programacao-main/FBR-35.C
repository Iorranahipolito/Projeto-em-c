#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main()
{
setlocale(LC_ALL, "portuguese");
printf("\n**********************************************************************************************************");
printf("\n*Aluno: FELIPE BUENO RAMOS - RA: 0025898                                                                 *");
printf("\n*Programa FBR-35 - Fibonacci                                                                             *");
printf("\n**********************************************************************************************************\n");

int n, i;
int a = 0, b = 1, c;
printf("Digite um numero: ");
scanf("%d", &n);

for(i = 1; i <= n; i++) {
    printf("%d ", a);
    c = a + b;
    a = b;
    b = c;
}

return 0;
}
