#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main()
{
setlocale(LC_ALL, "portuguese");
printf("\n**********************************************************************************************************");
printf("\n*Aluno: FELIPE BUENO RAMOS - RA: 0025898                                                                 *");
printf("\n*Programa FBR-15 - Quantas caixas cabem dentro do caminh�o                                               *");
printf("\n**********************************************************************************************************\n");

float altCam, largCam, compCam;
float altCx, largCx, compCx;
int qtd;

printf("Digite a Altura, largura e comprimento do caminhao: ");
scanf("%f %f %f", &altCam, &largCam, &compCam);

printf("Digite a Altura, largura e comprimento da caixa: ");
scanf("%f %f %f", &altCx, &largCx, &compCx);

qtd = (int)(altCam / altCx) *
      (int)(largCam / largCx) *
      (int)(compCam / compCx);

printf("Quantidade de caixas: %d\n", qtd);


return 0;
}
