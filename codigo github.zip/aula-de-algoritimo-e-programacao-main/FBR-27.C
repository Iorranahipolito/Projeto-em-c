#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main()
{
setlocale(LC_ALL, "portuguese");
printf("\n**********************************************************************************************************");
printf("\n*Aluno: FELIPE BUENO RAMOS - RA: 0025898                                                                 *");
printf("\n*Programa FBR-27 - Tabuada                                                                               *");
printf("\n**********************************************************************************************************\n");

int n, i;
printf("Digite um numero de 1 a 9: ");
scanf("%d", &n);

for(i = 1; i <= 10; i++)
    printf("%d x %d = %d\n", n, i, n * i);

return 0;
}
