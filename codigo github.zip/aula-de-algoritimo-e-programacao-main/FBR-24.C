#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main()
{
setlocale(LC_ALL, "portuguese");
printf("\n**********************************************************************************************************");
printf("\n*Aluno: FELIPE BUENO RAMOS - RA: 0025898                                                                 *");
printf("\n*Programa FBR-24 - Pode votar?                                                                           *");
printf("\n**********************************************************************************************************\n");

int idade;

printf("Digite sua idade: ");
scanf("%d", &idade);

if (idade >= 16)
    printf("Pode votar\n");
else
    printf("Nao pode votar\n");

return 0;
}
