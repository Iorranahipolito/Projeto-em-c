#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main()
{
setlocale(LC_ALL, "portuguese");
printf("\n**********************************************************************************************************");
printf("\n*Aluno: FELIPE BUENO RAMOS - RA: 0025898                                                                 *");
printf("\n*Programa FBR-19 - Ordem crescente                                                                       *");
printf("\n**********************************************************************************************************\n");

int a, b, c, temp;

printf("Digite Tres numeros: ");
scanf("%d %d %d", &a, &b, &c);

if (a > b) {
    temp = a; a = b; b = temp;
}

if (a > c) {
    temp = a; a = c; c = temp;
}

if (b > c) {
    temp = b; b = c; c = temp;
}

printf("%d %d %d\n", a, b, c);

return 0;
}
