#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main()
{
setlocale(LC_ALL, "portuguese");
printf("\n**********************************************************************************************************");
printf("\n*Aluno: FELIPE BUENO RAMOS - RA: 0025898                                                                 *");
printf("\n*Programa FBR-16 - M�ltiplo de 3 e/ou 5                                                                  *");
printf("\n**********************************************************************************************************\n");

int num;

printf("Digite um numero: ");
scanf("%d", &num);

if (num % 3 == 0 && num % 5 == 0)
    printf("Ganha refrigerante e sobremesa\n");
else if (num % 3 == 0)
    printf("Ganha refrigerante\n");
else if (num % 5 == 0)
    printf("Ganha sobremesa\n");
else
    printf("Nao ganhou premio\n");

return 0;
}
